package com.atguigu.yygh.hosp.mapper;

import com.atguigu.yygh.model.hosp.Schedule;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

public interface ScheduleMapper extends BaseMapper<Schedule> {
}
