package com.atguigu.yygh.order.mapper;

import com.atguigu.yygh.model.order.PaymentInfo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

public interface PaymentMapper extends BaseMapper<PaymentInfo> {
}
