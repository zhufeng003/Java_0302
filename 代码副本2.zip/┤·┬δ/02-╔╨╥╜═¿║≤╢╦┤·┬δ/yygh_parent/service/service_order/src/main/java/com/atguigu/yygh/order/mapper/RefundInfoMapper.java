package com.atguigu.yygh.order.mapper;

import com.atguigu.yygh.model.order.RefundInfo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

public interface RefundInfoMapper extends BaseMapper<RefundInfo> {
}
